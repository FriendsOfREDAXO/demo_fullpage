$(document).on('rex:ready', function (event, container) {
    container.find('.selectpicker').selectpicker();
});
